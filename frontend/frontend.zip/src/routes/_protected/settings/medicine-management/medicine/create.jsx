import {createFileRoute} from '@tanstack/react-router'
import MedicineForm from "@features/medicine/pages/pharmacy/medicines/form.jsx";

export const Route = createFileRoute(
    '/_protected/settings/medicine-management/medicine/create',
)({
    component: MedicineForm,
});
