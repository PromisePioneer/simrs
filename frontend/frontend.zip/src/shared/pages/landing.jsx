import {useEffect} from "react";

import Navbar from "@shared/components/landing/navbar.jsx";
import Hero from "@shared/components/landing/hero.jsx";
import Featured from "@shared/components/landing/featured.jsx";
import '../../assets/css/landing.css';
import DeviceMockup from "@shared/components/landing/device-mockup.jsx";
import Pricing from "@shared/components/landing/pricing.jsx";
import Contact from "@shared/components/landing/contact.jsx";
import Footer from "@shared/components/landing/footer.jsx";

function Landing() {

    useEffect(() => {
        const observerOptions = {
            root: null,
            rootMargin: "0px",
            threshold: 0.1,
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("visible");
                }
            });
        }, observerOptions);

        const fadeElements = document.querySelectorAll(".fade-in");
        fadeElements.forEach((el) => observer.observe(el));

        const anchors = document.querySelectorAll('a[href^="#"]');
        const smoothScroll = (e) => {
            e.preventDefault();
            const target = document.querySelector(e.currentTarget.getAttribute("href"));
            if (target) {
                target.scrollIntoView({behavior: "smooth"});
            }
        };

        anchors.forEach((anchor) =>
            anchor.addEventListener("click", smoothScroll)
        );

        return () => {
            fadeElements.forEach((el) => observer.unobserve(el));
            anchors.forEach((anchor) =>
                anchor.removeEventListener("click", smoothScroll)
            );
        };

    }, []);

    return (
        <>
            <Navbar/>

            <div className="fade-in" style={{'--delay': '0.1s'}}>
                <Hero/>
            </div>

            <div className="fade-in" style={{'--delay': '0.2s'}}>
                <Featured/>
            </div>

            <div className="fade-in" style={{'--delay': '0.3s'}}>
                <DeviceMockup/>
            </div>

            {/*<Testimonial/>*/}

            <div className="fade-in" style={{'--delay': '0.4s'}}>
                <Pricing/>
            </div>

            <div className="fade-in" style={{'--delay': '0.5s'}}>
                <Contact/>
            </div>

            <Footer/>
        </>
    );
}

export default Landing;