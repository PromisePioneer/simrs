<?php

declare(strict_types=1);

namespace Domains\MedicalWork\Domain\Repository;

use Domains\Shared\Domain\Repository\BaseRepositoryInterface;

interface ProfessionRepositoryInterface extends BaseRepositoryInterface {}

interface SpecializationRepositoryInterface extends BaseRepositoryInterface
{
    public function findByProfession(string $professionId, array $filters, ?int $perPage): object;
}

interface SubSpecializationRepositoryInterface extends BaseRepositoryInterface
{
    public function findBySpecialization(string $specializationId, array $filters, ?int $perPage): object;
}

interface DoctorScheduleRepositoryInterface extends BaseRepositoryInterface {}
