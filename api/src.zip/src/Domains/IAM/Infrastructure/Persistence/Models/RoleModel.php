<?php

namespace Domains\IAM\Infrastructure\Persistence\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Traits\HasRoles;

class RoleModel extends Role
{
    use HasRoles, HasUuids;

    protected string $guard_name = 'sanctum';
    protected $hidden = ['pivot'];

    protected $primaryKey = 'uuid';
    protected $table = 'roles';
    protected $fillable = [
        'name',
        'guard_name',
        'tenant_id'
    ];


}
