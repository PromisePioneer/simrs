<?php

use Domains\IAM\Presentation\Controllers\ModuleController;
use Domains\IAM\Presentation\Controllers\PermissionController;
use Domains\IAM\Presentation\Controllers\RoleController;
use Domains\IAM\Presentation\Controllers\UserController;
use Domains\Subscriptions\Presentation\Controllers\PlanController;
use Domains\Subscriptions\Presentation\Controllers\SubscriptionController;
use Illuminate\Support\Facades\Route;


Route::get('/modules', [ModuleController::class, 'index']);

Route::prefix('subscriptions')->group(function () {
    Route::get('/active', [SubscriptionController::class, 'active']);
    Route::post('/assign/{plan}', [SubscriptionController::class, 'assignSubs']);

    Route::prefix('plans')->group(function () {
        Route::apiResource('/', PlanController::class);
        Route::post('/bulk-destroy', [PlanController::class, 'bulkDestroy']);
    });
});

Route::middleware(['module:Setting'])->group(function () {
    Route::apiResource('permissions', PermissionController::class);

    Route::apiResource('/roles', RoleController::class);
    Route::prefix('roles')->group(function () {
        Route::get('/tenant/{tenant}', [RoleController::class, 'getByTenant']);
    });

    Route::prefix('users')->group(function () {
        Route::get('/', [UserController::class, 'index']);
        Route::post('/', [UserController::class, 'store']);
        Route::get('me', [UserController::class, 'me']);
        Route::get('{user}', [UserController::class, 'show']);
        Route::put('{user}', [UserController::class, 'update']);
        Route::delete('bulk', [UserController::class, 'bulkDestroy']);
    });

    Route::prefix('modules')->group(function () {
        Route::get('/data', [ModuleController::class, 'data']);
        Route::apiResource('/', ModuleController::class)->except(['index']);
        Route::put('/updated-module', [ModuleController::class, 'updatedModule']);
    });
});
