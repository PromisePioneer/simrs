<?php

declare(strict_types=1);

namespace Domains\Pharmacy\Domain\Repository;

interface MedicineRepositoryInterface
{
    public function getMedicines(array $filters = [], ?int $perPage = null): ?object;
    public function findById(string $id): ?object;
    public function store(array $data): ?object;
    public function update(string $id, array $data): ?object;
    public function destroy(string $id): ?object;
    public function findLastSequence(): ?object;
    public function getNextBatchFEFO(object $medicine): ?object;
    public function getReadyStocksMedicine(): ?object;

    public function bulkDelete(array $ids);
}
