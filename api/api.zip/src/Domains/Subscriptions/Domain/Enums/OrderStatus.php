<?php

declare(strict_types=1);

namespace Domains\Subscriptions\Domain\Enums;

enum OrderStatus: string
{
    case Pending   = 'pending';
    case Paid      = 'paid';
    case Expired   = 'expired';
    case Cancelled = 'cancelled';
}
