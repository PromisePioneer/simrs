<?php

namespace Domains\MasterData\Domain\Repository;

use Domains\Shared\Domain\Repository\BaseRepositoryInterface;

interface RegistrationInstitutionRepositoryInterface extends BaseRepositoryInterface
{
}
